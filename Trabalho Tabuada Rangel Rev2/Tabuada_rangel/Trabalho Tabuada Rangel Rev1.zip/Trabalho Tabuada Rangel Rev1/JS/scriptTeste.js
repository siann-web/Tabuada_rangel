import {numbers, operations, result, clear, display, deleteLast} from './QuerySelectorTeste.js';

numbers.forEach((number) => {
    number.addEventListener("click", () => {
        
        if(display.textContent === "0"){
            display.textContent = "";
        }
        display.textContent += number.textContent;
    });
});    
;
  operations.forEach((op) => {
    op.addEventListener("click", () => {
        display.textContent += op.textContent;
    }) 
});

result.addEventListener("click", () => {
    let tabuada = "";
    
    let operationIndice = display.textContent.indexOf('+');
    if(operationIndice !== -1){
        let number = parseInt(display.textContent.slice(0, operationIndice));
        for(let i = 1; i <= 10; i++){
            tabuada += `${parseFloat(number)} + ${i} = ${number + i}<br>`;
            display.innerHTML = tabuada;
        }
    }

    operationIndice = display.textContent.indexOf('-');
    if(operationIndice !== -1){
        let number = parseInt(display.textContent.slice(0, operationIndice));
        for(let i = 1; i <= 10; i++){
            tabuada += `${parseFloat(number)} - ${i} = ${number - i}<br>`;
            display.innerHTML = tabuada;
        }
    }

    operationIndice = display.textContent.indexOf('*');
    if(operationIndice !== -1){
        let number = parseInt(display.textContent.slice(0, operationIndice));
        for(let i = 1; i <= 10; i++){
            tabuada += `${parseFloat(number)} * ${i} = ${number * i}<br>`;
            display.innerHTML = tabuada;
        }
    }

    operationIndice = display.textContent.indexOf('/');
    if(operationIndice !== -1){
        let number = parseInt(display.textContent.slice(0, operationIndice));
        for(let i = 1; i <= 10; i++){
            tabuada += `${parseFloat(number)} / ${i} = ${number / i}<br>`;
            display.innerHTML = tabuada;
        }
    }
});

clear.addEventListener("click", () => {
    if(display.textContent !== ""){
        display.textContent = "";
    }

});

deleteLast.addEventListener("click", () => {
    if(display.textContent !== ""){
        let clearOne = display.textContent.length;
        display.textContent = display.textContent.slice(0, clearOne - 1);
    }
});