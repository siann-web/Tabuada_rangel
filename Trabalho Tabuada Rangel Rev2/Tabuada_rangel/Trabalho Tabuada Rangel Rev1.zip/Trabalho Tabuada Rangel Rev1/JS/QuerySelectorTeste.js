export var numbers = document.querySelectorAll(".numbers div");
export var operations = document.querySelectorAll(".operations div");
export var result = document.querySelector("#result");
export var deleteLast = document.querySelector("#delete");
export var clear = document.querySelector("#clear");
export var display = document.querySelector(".display");