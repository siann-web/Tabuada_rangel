// Autor: Ruan Bruno da Silva
// rbs = Ruan Bruno da Silva

const rbs_numero_1 = document.getElementById('um').addEventListener('click', function(){
    let rbs_numero = 1;
    let rbs_tabuada = '';
    let rbs_add_evento_operaçao = document.getElementById('add').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} + ${i} = ${rbs_numero + i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_sub_evento_operaçao = document.getElementById('substract').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} - ${i} = ${rbs_numero - i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_mult_evento_operaçao = document.getElementById('multiply').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';} 
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} x ${i} = ${rbs_numero * i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_div_evento_operaçao = document.getElementById('divide').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} / ${i} = ${rbs_numero / i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});            
});
const rbs_numero_2 = document.getElementById('dois').addEventListener('click', function(){
    let rbs_numero = 2;
    let rbs_tabuada = '';
    let rbs_add_evento_operaçao = document.getElementById('add').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} + ${i} = ${rbs_numero + i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_sub_evento_operaçao = document.getElementById('substract').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} - ${i} = ${rbs_numero - i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_mult_evento_operaçao = document.getElementById('multiply').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';} 
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} x ${i} = ${rbs_numero * i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_div_evento_operaçao = document.getElementById('divide').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} / ${i} = ${rbs_numero / i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});            
});
const rbs_numero_3 = document.getElementById('tres').addEventListener('click', function(){
    let rbs_numero = 3;
    let rbs_tabuada = '';
    let rbs_add_evento_operaçao = document.getElementById('add').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} + ${i} = ${rbs_numero + i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_sub_evento_operaçao = document.getElementById('substract').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} - ${i} = ${rbs_numero - i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_mult_evento_operaçao = document.getElementById('multiply').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';} 
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} x ${i} = ${rbs_numero * i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_div_evento_operaçao = document.getElementById('divide').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} / ${i} = ${rbs_numero / i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});            
});
const rbs_numero_4 = document.getElementById('quatro').addEventListener('click', function(){
    let rbs_numero = 4;
    let rbs_tabuada = '';
    let rbs_add_evento_operaçao = document.getElementById('add').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} + ${i} = ${rbs_numero + i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_sub_evento_operaçao = document.getElementById('substract').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} - ${i} = ${rbs_numero - i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_mult_evento_operaçao = document.getElementById('multiply').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';} 
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} x ${i} = ${rbs_numero * i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_div_evento_operaçao = document.getElementById('divide').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} / ${i} = ${rbs_numero / i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});            
});
const rbs_numero_5 = document.getElementById('cinco').addEventListener('click', function(){
    let rbs_numero = 5;
    let rbs_tabuada = '';
    let rbs_add_evento_operaçao = document.getElementById('add').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} + ${i} = ${rbs_numero + i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_sub_evento_operaçao = document.getElementById('substract').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} - ${i} = ${rbs_numero - i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_mult_evento_operaçao = document.getElementById('multiply').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';} 
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} x ${i} = ${rbs_numero * i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_div_evento_operaçao = document.getElementById('divide').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} / ${i} = ${rbs_numero / i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});            
});
const rbs_numero_6 = document.getElementById('seis').addEventListener('click', function(){
    let rbs_numero = 6;
    let rbs_tabuada = '';
    let rbs_add_evento_operaçao = document.getElementById('add').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} + ${i} = ${rbs_numero + i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_sub_evento_operaçao = document.getElementById('substract').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} - ${i} = ${rbs_numero - i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_mult_evento_operaçao = document.getElementById('multiply').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';} 
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} x ${i} = ${rbs_numero * i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_div_evento_operaçao = document.getElementById('divide').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} / ${i} = ${rbs_numero / i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});            
});
const rbs_numero_7 = document.getElementById('sete').addEventListener('click', function(){
    let rbs_numero = 7;
    let rbs_tabuada = '';
    let rbs_add_evento_operaçao = document.getElementById('add').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} + ${i} = ${rbs_numero + i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_sub_evento_operaçao = document.getElementById('substract').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} - ${i} = ${rbs_numero - i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_mult_evento_operaçao = document.getElementById('multiply').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';} 
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} x ${i} = ${rbs_numero * i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_div_evento_operaçao = document.getElementById('divide').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} / ${i} = ${rbs_numero / i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});            
});
const rbs_numero_8 = document.getElementById('oito').addEventListener('click', function(){
    let rbs_numero = 8;
    let rbs_tabuada = '';
    let rbs_add_evento_operaçao = document.getElementById('add').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} + ${i} = ${rbs_numero + i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_sub_evento_operaçao = document.getElementById('substract').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} - ${i} = ${rbs_numero - i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_mult_evento_operaçao = document.getElementById('multiply').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';} 
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} x ${i} = ${rbs_numero * i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_div_evento_operaçao = document.getElementById('divide').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} / ${i} = ${rbs_numero / i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});            
});
const rbs_numero_9 = document.getElementById('nove').addEventListener('click', function(){
    let rbs_numero = 9;
    let rbs_tabuada = '';
    let rbs_add_evento_operaçao = document.getElementById('add').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} + ${i} = ${rbs_numero + i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_sub_evento_operaçao = document.getElementById('substract').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} - ${i} = ${rbs_numero - i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_mult_evento_operaçao = document.getElementById('multiply').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';} 
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} x ${i} = ${rbs_numero * i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});
     let rbs_div_evento_operaçao = document.getElementById('divide').addEventListener('click', function(){
        if(rbs_tabuada != ''){rbs_tabuada = '';}
            for(let i = 1; i <= 10; i++){
                rbs_tabuada += `${rbs_numero} / ${i} = ${rbs_numero / i}<br>`;
                resultado.innerHTML = rbs_tabuada;
            }});            
});